import csv

d = {}
lc= 0

with open("B2E.csv", 'r',encoding="utf8") as data:
    for line in csv.reader(data):
            if(lc!=0):
                d[line[0]] = line[1:]
            lc=1

d2 = {v: k for k in d for v in d[k] if v!=''}

with open('E2B.csv', 'w',encoding="utf8") as csv_file:
    writer = csv.writer(csv_file)
    for key, value in d2.items():
       writer.writerow([key, value])